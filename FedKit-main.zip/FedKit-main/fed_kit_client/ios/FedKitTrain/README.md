# FedKit Training Swift Package

To use this package, open the example client in Xcode and copy the files.