# CIFAR10 Example TFLite Model

This model uses the exact same Keras model as the one from Flower Android example.

## Running

At `../..`, run:

```sh
python3 -m convert_model.cifar10_eg.run
```
